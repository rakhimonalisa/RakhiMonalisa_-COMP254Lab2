package visualizerunningtime;

import java.util.Random;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;


public class VisualizeRunningTime extends Application {
    
      
  public static double[] GenerateArray(int n)
  { double[] array = new double[n];
  
  for (int i = 0; i < n ;i++) 
  {
      Random random = new Random();
      int anyNum = random.nextInt(1000); 
      array[i] =  anyNum;
  }
      return array;
  }
    
     
  public static double[] prefixAverage1(double[] x) {
    int n = x.length;
    double[] a = new double[n];    
    for (int j=0; j < n; j++) {
      double total = 0;            
      for (int i=0; i <= j; i++)
        total += x[i];
      a[j] = total / (j+1);        
    }
    return a;
  }

  
  public static double[] prefixAverage2(double[] x) {
    int n = x.length;
    double[] a = new double[n];    
    double total = 0;              
    for (int j=0; j < n; j++) {
      total += x[j];               
      a[j] = total / (j+1);        
    }
    return a;
  }
    
    @Override
    public void start(Stage stage) {
        stage.setTitle("Line Chart Sample");
        Button btn = new Button();
        btn.setText("Say 'Hello World'");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });
        
       
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("");
        
        final LineChart<Number,Number> lineChart = 
                new LineChart<Number,Number>(xAxis,yAxis);
                
        lineChart.setTitle("Visualization");
        
        XYChart.Series series = new XYChart.Series();
        series.setName("Lab 2 - Rakhi Monalisa");
        
        int i = 0;
        for(double d:prefixAverage1(GenerateArray(10)))
        {
            i++;
            series.getData().add(new XYChart.Data(i, d));
        }
        
        
        
        Scene scene  = new Scene(lineChart,800,600);
        lineChart.getData().add(series);
       
        stage.setScene(scene);
        stage.show();
    }
    
    

    
    public static void main(String[] args) {
        launch(args);
    }
    
}

