package uniquenessexperimentalanalysis;

import java.util.Arrays;
import java.util.Random;


public class LargestNAnalysis {


  
  public static boolean unique2(int[] data) {
    int n = data.length;
    int[] temp = Arrays.copyOf(data, n);   
    Arrays.sort(temp);                     
    for (int j=0; j < n-1; j++)
      if (temp[j] == temp[j+1])            
        return false;                      
    return true;                           
  }
    
        
  public static boolean unique1(int[] data) {
    int n = data.length;
    for (int j=0; j < n-1; j++)
      for (int k=j+1; k < n; k++)
        if (data[j] == data[k])
          return false;                    
    return true;                           
  }


    
  
  public static int MaxArraySizeUnder1Min(int n, int u)
  {   
      int s = n;
      long startTime ; 
      long endTime;
      long timeElapsed = 0;
      
      
      if (u == 1){
      while(timeElapsed < 5000) 
      {
          startTime = System.currentTimeMillis(); 
          
          unique1(GenerateArray(s)); 
          
          endTime = System.currentTimeMillis();
          timeElapsed = endTime - startTime; 
            
          
          
         if(timeElapsed > 5000 && s!= n)
         {
             s --;
             
             return MaxArraySizeUnder1Min(s, 1);
         }
         
         else if(timeElapsed > 5000 && s == n)
             return s;
         
            
            s = s * 2; 
      }
      
      }
      
      else if (u ==2){
          while(timeElapsed < 5000) 
      {
          startTime = System.currentTimeMillis(); 
          
          unique2(GenerateArray(s)); 
          
          endTime = System.currentTimeMillis();
          timeElapsed = endTime - startTime; 
            
          
          
         if(timeElapsed > 5000 && s!= n)
         {
             s --;
             
             return MaxArraySizeUnder1Min(s, 1);
         }
         
         else if(timeElapsed > 5000 && s == n)
             return s;
         
            
            s = s * 2; 
      }
      }
  
  return n; 
  }
  
  
  public static int[] GenerateArray(int n)
  { int[] array = new int[n];
  
  for (int i = 0; i < n ;i++) 
  {
      Random random = new Random();
      int anyNum = random.nextInt(1000);
      array[i] =  anyNum;
  }
      return array;
  }
  
      public static void main(String[] args) {
        int maxSize1 = MaxArraySizeUnder1Min(100,1);
        int maxSize2 = MaxArraySizeUnder1Min(100,2);
        
          System.out.println("Maximum array size to execute in less than 5 seconds for 'Unique1' is: "+maxSize1);
          System.out.println("Maximum array size to execute in less than 5 seconds for 'Unique2' is: "+maxSize2);
    }

}